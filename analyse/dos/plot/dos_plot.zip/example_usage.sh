#Run ./dos_from_gaussians.py -h for all options

./dos_from_gaussians.py dos_*.dat --interpolate

./dos_from_gaussians.py dos_*.dat --interpolate --split_updown
